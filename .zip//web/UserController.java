package com..springboot.web;
@RestController
@RequestMapping(/"user")
public class UserController {

	@Autowiredprivate UserRepository userRepository;

	@RequestMapping("/")
	public List<User> getUser() {
	List<User> list = userRepository.findAll();
	return list;
	}

	public User getUser(@PathVariable("id") String id) 
	{	User user = userRepository.findById(Long.parseLong(id));
	return customer;
 	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void deleteUser(@PathVariable String id) {
	User user = userRepository.findOne(Long.parseLong(id));
	userRepository.save(user);
	}
	}