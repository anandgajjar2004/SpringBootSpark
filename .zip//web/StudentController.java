package com..springboot.web;
@RestController
@RequestMapping(/"student")
public class StudentController {

	@Autowiredprivate StudentRepository studentRepository;

	@RequestMapping("/")
	public List<Student> getStudent() {
	List<Student> list = studentRepository.findAll();
	return list;
	}

	public Student getStudent(@PathVariable("id") String id) 
	{	Student student = studentRepository.findById(Long.parseLong(id));
	return customer;
 	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void deleteStudent(@PathVariable String id) {
	Student student = studentRepository.findOne(Long.parseLong(id));
	studentRepository.save(student);
	}
	}